# Backoffice Visibilité et réputation — Satisfaction client

Status: Phase 3A visual proposal awaiting human review

Visibility: Engineering

Owner: YUTA product and engineering

Protocol revision: 4

Application: `apps/backoffice`

Target type: `PAGE`

Route / entry point: `/visibilite-reputation/satisfaction`

Runtime family: `CLOUD`

Page classification: `EXISTING_PAGE`

Implementation class: `integrated`

Package status: `design`

Scope status: `APPROVED`

Reference status: `DRAFT`

Inventory status: `COMPLETE`

Baseline status: `CAPTURED`

Design prompt status: `READY`

Shared context status: `RESOLVED`

Prompt snapshot topology: `GENERATED_SNAPSHOTS`

Prompt provenance: `prompt-provenance.json`

No-image reference reason: `NOT_APPLICABLE — authenticated current-page captures are attached; no generated design has been approved yet.`

## Current implementation

The existing authenticated route is a persisted Direct Customer Feedback inbox.
`satisfaction/page.tsx` loads the shared Reputation review page in `direct` mode.
The server loader resolves the authenticated tenant, trusted organization and
active establishment, enforces `reputation.read`, fixes the source to `DIRECT`,
and loads the current list, counters, selected review, detail and assignable
users. Current actions update feedback status, assignment, internal notes and
related review management through the existing server boundary.

The current route does not render the approved “Liens d’avis et réseaux
sociaux” settings section. Phase 1 and Phase 2 of
`reputation-review-social-links-configuration` already provide the shared URL
policy, typed outcomes, scoped repository behavior, conflict/reload semantics,
no-op behavior, audit behavior, safe public projection and fail-closed missing
settings-row result. This page package references those approved artifacts; it
does not redefine them.

## Authority

Read in order:

1. root `AGENTS.md` and `apps/backoffice/AGENTS.md`;
2. `docs/CURRENT_STATE.md`, `docs/AUTHORITY_MODEL.md` and Reputation product
   knowledge;
3. `docs/ui/README.md`, `docs/ui/DESIGN_TO_CODE_WORKFLOW.md`,
   `docs/ui/PAGE_PACK_PROTOCOL.md`, `docs/ui/YUTA_FRONTEND_RULES.md` and
   `docs/ui/BACKOFFICE_FRONTEND_RULES.md`;
4. approved Proposal, Analysis, Spec, Design and Tasks for
   `reputation-review-social-links-configuration`;
5. current route, shared components, contracts, repository, authorization and
   tests;
6. this page package and its sealed prompt snapshots.

## Documents

- `PRODUCT_SCOPE.md`
- `UI_SPEC.md`
- `DATA_AND_INTERACTION_SPEC.md`
- `DESIGN_HANDOFF.md`
- `IMPLEMENTATION_PLAN.md`
- `ACCEPTANCE_CHECKLIST.md`

## References

- `references/baseline-owner-1440x900.png` — desktop authenticated OWNER
  baseline and full two-column inbox.
- `references/baseline-owner-1024x768.png` — compact desktop/tablet baseline.
- `references/baseline-owner-768x1024.png` — narrow authenticated Backoffice
  baseline with current responsive stacking.
- `references/baseline-owner-390x844.png` — current mobile shell and above-fold
  content.
- `references/proposed-owner-1440x900.png` — proposed compact desktop placement
  between metrics and inbox.
- `references/proposed-owner-1024x768.png` — proposed scrolled view showing the
  settings card after the inbox.
- `references/proposed-owner-768x1024.png` — proposed narrow stacked form after
  the inbox.
- `references/proposed-owner-390x844.png` — proposed mobile single-column form
  after the inbox.

The baseline captures are current-state evidence. The proposed images are
visual authority candidates awaiting human approval. Neither class of image
defines permissions or product behavior.

## Shared UI context

Shell mode: `REUSE_CURRENT_TARGET`.

Reuse the existing authenticated `BackofficeFrame`, sidebar/mobile navigation,
top bar, establishment switcher, account/session area, footer, content width,
Geist typography, semantic tokens, `@yuta/ui` primitives and `lucide-react`.
The current “Satisfaction client” navigation entry and route stay unchanged.
The page may add only the approved OWNER-only settings section while preserving
the Direct Customer Feedback inbox as the primary capability. It must not
redesign the application shell or create a route, navigation item, dashboard,
provider connection flow or shared primitive.

## Protected invariants

- The route keeps its current `reputation.read` access for OWNER, MANAGER and
  STAFF when their trusted membership and active establishment are valid.
- The settings section is available only after server-side
  `reputation.settings.manage`; MANAGER and STAFF keep the inbox but receive no
  settings model or settings UI.
- Organization, establishment, membership, role and permissions come from the
  authenticated server context, never from browser claims.
- The Direct Customer Feedback source remains server-fixed to `DIRECT`; query
  input cannot widen it.
- The three settings values belong to Reputation and remain scoped by trusted
  organization plus establishment.
- Missing settings rows fail closed as `CONFIGURATION_UNAVAILABLE`; this page
  cannot create or provision a row or infer unrelated Reputation fields.
- One explicit Save covers all three fields. No autosave, partial write,
  provider call or OAuth behavior is introduced.
- Public rendering continues to use the shared safe projection. The concurrent
  `feedback-public-trusted-boundary-hardening` change owns hostname and client
  identity hardening and explicitly excludes external review URLs/settings.
- No polling, offline queue or device integration applies to this page.

## Change impact

```text
Phase 3A files created: this page package and authenticated baseline references
Future Phase 3B files proposed: existing Satisfaction route, route-local action/component/model tests
Future Phase 3C files proposed: minimal feedback-web safe-link consumption only after separate authorization
Packages affected in Phase 3A: docs only
Cross-application impact in Phase 3A: NO
Database change: NO
API or contract change: NO — reuse approved Phase 1/2 contracts
Permission/auth change: NO — reuse reputation.settings.manage
Runtime/device change: NO
```

## Design approval

The Product, behavioral Spec, Technical Design, Phase 1 contracts and Phase 2
domain implementation are approved. The visual prompt has now produced four
responsive proposals. Their exact placement and state treatment are recorded in
`UI_SPEC.md` and `DESIGN_HANDOFF.md`; they remain `DRAFT` until the current human
review approves their bytes. No UI implementation is approved by this document.

Required next gate: `PAGE_PACK_APPROVED_BEFORE_UI_CODE`.

## Prompt order

1. `prompts/00_REPOSITORY_ANALYSIS.md`
2. `prompts/01_VISUAL_BASELINE.md`
3. `prompts/02_COMPONENT_REFACTOR.md`
4. `prompts/03_INTERACTIONS.md`
5. `prompts/04_DATA_INTEGRATION.md`
6. `prompts/05_VISUAL_QA.md`

The snapshots are sealed by `prompt-provenance.json`. Do not edit them in place.
Later canonical-template changes do not rewrite this generated pack.

## Stop conditions

Stop before UI code until this exact page pack is approved. Stop again if later
implementation requires a new route/navigation item, permission or role grant,
schema/migration, settings-row provisioning, provider/OAuth call, analytics,
QR, social publishing, AI, shared UI primitive change, tenant-boundary change,
or reinterpretation of `feedback-public-trusted-boundary-hardening`.

## Final delivery and as-built status

Final implementation locations/files changed: `PENDING — Phase 3B/3C not authorized`

Verification commands and results: `Phase 3A documentation checks recorded in the review evidence`

Functional/regression QA result: `NOT_STARTED`

Visual/browser/device evidence: `Current authenticated baseline only; Browser QA NOT_STARTED`

Intentional deviations: `No UI implementation was produced; proposed images are design references only.`

Deferred proposals and risks: `Settings UI/action, public CTA adjustment, final integration and Browser QA remain separately gated.`

As-built documentation status: `PENDING`
